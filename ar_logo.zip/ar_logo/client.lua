local display = true

CreateThread(function()
    while true do
        Wait(0)
        SetNuiFocus(false, false)
        SendNUIMessage({
            type = "display",
            display = display
        })
    end
end)

CreateThread(function()
    while true do
        Wait(1000)  -- Check every second
        if IsPauseMenuActive() then
            display = false
        else
            display = true
        end
    end
end)
