fx_version 'cerulean'
game 'gta5'

author 'AR Development'
description 'Display server logo'
version '1.0.0'

client_scripts {
    'client.lua'
}

files {
    'ui/index.html',
    'ui/style.css',
    'assets/images/logo.png'
}

ui_page 'ui/index.html'
